<?php

echo $_GET["id"];
echo "<br>";
echo $_GET["idk"];

?>