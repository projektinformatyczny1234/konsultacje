<?php

	$host = "localhost";
	$db_user = "id19769044_user1234";
	$db_password = "9r^ou#@}SD7DYN9d";
	$db_name = "id19769044_projekt";
	
?>